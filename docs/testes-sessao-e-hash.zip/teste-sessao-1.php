<?php

	session_start();
	
	$_SESSION['professor']="Jivago Medeiros";
	$_SESSION['cod-disciplina']="3052668";
	$_SESSION['tipo']=$_GET['tipo'];
	$_SESSION['cod']=$_GET['cod'];


?>
<a href="teste-sessao-2.php">Ir para segunda pagina</a>