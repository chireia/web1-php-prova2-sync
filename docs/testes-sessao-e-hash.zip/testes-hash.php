<?php
	$senha = "minhasenha";

	$bytes = random_bytes(10);
	
	$salt = bin2hex($bytes);
	
	echo "<br />".$salt."<br />";
	
	$salzinho = "1dac3das21";
	
	$hash = $senha.$salzinho;
	
	echo md5($hash);

?>