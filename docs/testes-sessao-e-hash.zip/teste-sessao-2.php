<?php

	session_start();

	echo "<br />PROFESSOR: ".$_SESSION['professor'];	
	echo "<br />DISCIPLINA: ".$_SESSION['cod-disciplina'];
	echo "<br />TIPO: ".$_SESSION['tipo'];
	echo "<br />COD: ".$_SESSION['cod'];
	
	unset($_SESSION['cod-disciplina']);

?>