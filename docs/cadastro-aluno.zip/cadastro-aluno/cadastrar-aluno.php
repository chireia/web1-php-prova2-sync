<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
	</head>
	<body>
		<?php
		
			//error_reporting(~E_NOTICE);
		
			if (isset($_GET['tipo']) && isset($_GET['cod'])) {
				echo "<br />".$_GET['tipo'];
				echo "<br />".$_GET['cod'];			
			}
		
			$con = mysqli_connect("localhost","root","root");
			mysqli_select_db($con,"paw");
		
	//um mínimo de segurança
	$nome = mysqli_real_escape_string($con,$_REQUEST['txt-nome']);
	$rga  = (int) $_REQUEST['txt-rga'];
			
			echo '<br /> $nome'; //não funciona
			echo "<br /> $nome"; //funciona
			
			$sqlInsert = "INSERT INTO aluno (nome,rga)
							VALUES ('".$nome."','$rga')";
			
			$retorno = mysqli_query($con,$sqlInsert);
			
			if ($retorno==true) {
				echo "<div style='color: green'>Aluno cadastrado!</div>";
			}
			else {
				?>
			<div style="color: orange">Erro cadastrando aluno</div>
				<?php
			}
			
			
		if (isset($_GET['tipo']) && isset($_GET['cod'])) {
			
		?>
		<a href="../teste-sessao-1.php?tipo=<?php echo $_GET['tipo']  ?>&cod=<?php echo $_GET['cod']  ?>">
			Ir para sessão
		</a>
		<?php
		}
		?>
	</body>
</html>